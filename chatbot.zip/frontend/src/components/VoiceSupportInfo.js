import React from 'react';

const VoiceSupportInfo = () => {
  return null; // Không hiển thị gì cả
};

export default VoiceSupportInfo;
